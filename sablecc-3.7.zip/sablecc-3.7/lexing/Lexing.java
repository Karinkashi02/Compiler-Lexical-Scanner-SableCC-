package lexing;
import lexing.lexer.*;
import lexing.node.*;
import java.io.*; // Needed for pushbackreader and inputstream

class Lexing
{
static Lexer lexer;
static Object token;

public static void main(String [] args)
{
lexer = new Lexer(new PushbackReader(new InputStreamReader(System.in),1024));
token = null;

try
{
while ( ! (token instanceof EOF))
{ token = lexer.next(); // read next token

if (token instanceof TNumber) {
    System.out.print ("Number: ");
    System.out.println(token);
}

else if (token instanceof TIdent) {
    System.out.print ("Identifier: ");
    System.out.println(token);
}

else if (token instanceof TAssignOp) {
    System.out.print ("Assignment: ");
    System.out.println(token);
}

else if (token instanceof TRelOp) {
    System.out.print ("Comparison Op: ");
    System.out.println(token);
}

else if (token instanceof TArithOp) {
    System.out.print ("Arithmetic Op: ");
    System.out.println(token);
}

else if (token instanceof TNotOp) {
    System.out.print ("Logic Op: ");
    System.out.println(token);
}

else if (token instanceof TAndOp) {
    System.out.print ("Logic Op: ");
    System.out.println(token);
}

else if (token instanceof TOrOp) {
    System.out.print ("Logic Op: ");
    System.out.println(token);
}

else if (token instanceof TDot) {
    System.out.print ("Access Op: ");
    System.out.println(token);
}

else if (token instanceof TLBracket) {
    System.out.print ("Access Op: ");
    System.out.println(token);
}

else if (token instanceof TRBracket) {
    System.out.print ("Access Op: ");
    System.out.println(token);
}

else if (token instanceof TParen) {
    System.out.print ("Parentheses: ");
    System.out.println(token);
}

else if (token instanceof TKeyword) {
    System.out.print ("Keyword: ");
    System.out.println(token);
}

else if (token instanceof TSpecialChar) {
    System.out.print ("Special Char: ");
    System.out.println(token);
}

else if (token instanceof TBlank) {
    System.out.print ("Blank: ");
    System.out.println(token); 
}

else if (token instanceof TUnknown) {
    System.out.print ("Unknown: ");
    System.out.println(token);
}

}
}
catch (LexerException le)
{ System.out.println ("Lexer Exception " + le); }

catch (IOException ioe)
{ System.out.println ("IO Exception " +ioe); }
}
}
